export class ApiResponse {
  result: any;
  status: any;
  message: any; 
}
